
window.location.replace("https://youtube.com/");
